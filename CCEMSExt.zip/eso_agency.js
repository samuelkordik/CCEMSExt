 //Set Company ID
document.querySelector('#AgencyLoginId').value = 'cycreek';
console.log('ran ESO');