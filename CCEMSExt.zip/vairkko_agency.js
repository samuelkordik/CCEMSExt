//Set Company ID
document.querySelector('#companyid').value = 366;
console.log('ran VKO');